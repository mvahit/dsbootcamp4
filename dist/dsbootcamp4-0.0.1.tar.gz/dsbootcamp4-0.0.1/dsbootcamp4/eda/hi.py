def hello():
    print("Hello!")

def hello2():
    print("Hej Hej!!!")
