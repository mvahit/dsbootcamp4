def hello():
    print("Hi")

def hello2():
    print("Hej Hej!")